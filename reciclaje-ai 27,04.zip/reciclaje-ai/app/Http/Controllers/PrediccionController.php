<?php

namespace App\Http\Controllers;

use App\Models\Pesaje;

class PrediccionController extends Controller
{
    public function index()
    {
        $userId = auth()->id();

        // 🔹 Datos históricos (por día)
        $porDia = Pesaje::where('user_id', $userId)
            ->selectRaw('DATE(fecha) as dia, SUM(peso) as total')
            ->groupBy('dia')
            ->orderBy('dia')
            ->get();

        $fechas = $porDia->pluck('dia');
        $totales = $porDia->pluck('total');

        // 🔹 Exportar CSV para Python
        $rutaCSV = storage_path('app/private/datos.csv');

        $csv = "dia,total\n";
        foreach ($porDia as $row) {
            $csv .= $row->dia . "," . $row->total . "\n";
        }

        file_put_contents($rutaCSV, $csv);

        // 🤖 Ejecutar modelo Python
        $output = [];
        $return = 0;

        exec("C:\\laragon\\bin\\python\\python-3.13\\python.exe " . base_path("modelo.py"), $output, $return);

        $prediccion = 0;
        $outliers = 0;

        if (isset($output[0])) {
            $datos = explode(',', $output[0]);
            $prediccion = floatval($datos[0]);
            $outliers = isset($datos[1]) ? intval($datos[1]) : 0;
        }

        return view('prediccion', compact(
            'prediccion',
            'outliers',
            'fechas',
            'totales'
        ));
    }
}