<?php

namespace App\Http\Controllers;

use App\Models\Pesaje;

class DashboardController extends Controller
{
    public function index()
    {
        $userId = auth()->id();

        // 🔹 Total hoy
        $totalHoy = Pesaje::where('user_id', $userId)
            ->whereDate('fecha', now()->toDateString())
            ->sum('peso');

        // 🔹 Total general
        $totalGeneral = Pesaje::where('user_id', $userId)
            ->sum('peso');

        // 🔹 Últimos registros
        $ultimos = Pesaje::where('user_id', $userId)
            ->latest()
            ->take(5)
            ->get();

        // 🔥 Datos por día
        $porDia = Pesaje::where('user_id', $userId)
            ->selectRaw('DATE(fecha) as dia, SUM(peso) as total')
            ->groupBy('dia')
            ->orderBy('dia')
            ->get();

        $fechas = $porDia->pluck('dia');
        $totales = $porDia->pluck('total');

        // 🔥 EXPORTAR CSV
        $rutaCSV = storage_path('app/private/datos.csv');

        $csv = "dia,total\n";
        foreach ($porDia as $row) {
            $csv .= $row->dia . "," . $row->total . "\n";
        }

        file_put_contents($rutaCSV, $csv);

        // 🤖 IA (Python)
        $output = [];
        $return = 0;

        exec("C:\\laragon\\bin\\python\\python-3.13\\python.exe " . base_path("modelo.py"), $output, $return);

$prediccion = 0;
$outliers = 0;

if(isset($output[0])) {
    $datos = explode(',', $output[0]);

    $prediccion = floatval($datos[0]);
    $outliers = isset($datos[1]) ? intval($datos[1]) : 0;
}

return view('dashboard', compact(
    'totalHoy',
    'totalGeneral',
    'ultimos',
    'fechas',
    'totales',
    'prediccion',
    'outliers'
));  

    }
}