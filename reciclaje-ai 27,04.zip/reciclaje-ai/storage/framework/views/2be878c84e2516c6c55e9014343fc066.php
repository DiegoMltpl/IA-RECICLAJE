<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<div class="p-6 bg-gray-100 min-h-screen">

    <!-- 🔹 GRID PRINCIPAL -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

        <!-- IZQUIERDA -->
        <div class="lg:col-span-2 space-y-6">

            <!-- TARJETAS -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">

                <div class="bg-white p-4 rounded-xl shadow">
                    <p class="text-gray-500 text-sm">Total hoy</p>
                    <h2 class="text-2xl font-bold text-green-600"><?php echo e($totalHoy); ?> kg</h2>
                </div>

                <div class="bg-white p-4 rounded-xl shadow">
                    <p class="text-gray-500 text-sm">Total general</p>
                    <h2 class="text-2xl font-bold text-blue-600"><?php echo e($totalGeneral); ?> kg</h2>
                </div>

                <div class="bg-white p-4 rounded-xl shadow">
                    <p class="text-gray-500 text-sm">Predicción IA</p>
                    <h2 class="text-2xl font-bold text-purple-600">
                        <?php echo e(number_format($prediccion,2)); ?> kg
                    </h2>
                </div>

            </div>

            <!-- GRÁFICA -->
            <div class="bg-white p-5 rounded-xl shadow">
                <h2 class="text-lg font-semibold text-gray-700 mb-3">Tendencia de reciclaje</h2>
                <canvas id="grafica"></canvas>
            </div>

        </div>

        <!-- DERECHA -->
        <div class="space-y-6">

            <!-- ANÁLISIS -->
            <div class="bg-white p-5 rounded-xl shadow">
                <h2 class="text-md font-semibold text-gray-700 mb-2">Análisis</h2>

                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($prediccion > 60): ?>
                    <p class="text-green-600 font-medium">Alto nivel de reciclaje esperado</p>
                <?php else: ?>
                    <p class="text-red-500 font-medium">Nivel bajo, mejorar recolección</p>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

                <p class="text-sm text-gray-500 mt-2">
                    Datos atípicos: <?php echo e($outliers ?? 0); ?>

                </p>
            </div>

            <!-- ÚLTIMOS -->
            <div class="bg-white p-5 rounded-xl shadow">
                <h2 class="text-md font-semibold text-gray-700 mb-2">Últimos registros</h2>

                <div class="space-y-2 text-sm">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $ultimos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex justify-between border-b pb-1">
                            <span class="text-gray-600"><?php echo e(ucfirst($p->material)); ?></span>
                            <span class="font-semibold"><?php echo e($p->peso); ?> kg</span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>
            </div>

            <!-- BOTÓN -->
            <a href="/pesajes/create"
               class="block text-center bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-xl shadow transition">
                Registrar nuevo pesaje
            </a>

        </div>

    </div>

</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
    new Chart(document.getElementById('grafica'), {
        type: 'line',
        data: {
            labels: <?php echo json_encode($fechas, 15, 512) ?>,
            datasets: [{
                label: 'Kg por día',
                data: <?php echo json_encode($totales, 15, 512) ?>,
                borderWidth: 2,
                tension: 0.3
            }]
        }
    });
</script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\reciclaje-ai\resources\views/dashboard.blade.php ENDPATH**/ ?>