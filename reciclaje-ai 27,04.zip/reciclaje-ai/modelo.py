import pandas as pd
from sklearn.ensemble import RandomForestRegressor
import warnings
import sys
import os

warnings.filterwarnings("ignore")

# 📁 Ruta absoluta del CSV
base = os.path.dirname(os.path.abspath(__file__))
ruta = os.path.join(base, "storage", "app", "private", "datos.csv")

df = pd.read_csv(ruta)

# 🧹 DEPURACIÓN

df = df.dropna()
df = df[df['total'] >= 0]

# eliminar valores extremos
media = df['total'].mean()
std = df['total'].std()

df = df[(df['total'] > media - 2*std) & (df['total'] < media + 2*std)]

# validar datos
if len(df) < 2:
    print("0,0")
    exit()

# 🧠 VARIABLES NUEVAS
df['dia_num'] = range(len(df))
df['dia_semana'] = pd.to_datetime(df['dia']).dt.dayofweek

X = df[['dia_num', 'dia_semana']]
y = df['total']

# 🤖 MODELO MÁS AVANZADO
model = RandomForestRegressor(n_estimators=100)
model.fit(X, y)

# 🔮 PREDICCIÓN
next_day = [[len(df), (len(df) % 7)]]
pred = model.predict(next_day)

# 🚨 DETECCIÓN DE ANOMALÍAS
outliers = df[df['total'] > media + 2*std]
cantidad_outliers = len(outliers)

# 📤 SALIDA (IMPORTANTE)
resultado = f"{pred[0]},{cantidad_outliers}"

sys.stdout.write(resultado)
sys.stdout.flush()