<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PesajeController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\PrediccionController;

Route::get('/', function () {
    return view('welcome');
});

Route::middleware([
    'auth:sanctum',
    config('jetstream.auth_session'),
    'verified',
])->group(function () {

    // DASHBOARD
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');

    // PESAJES
    Route::get('/pesajes', [PesajeController::class, 'index']);
    Route::get('/pesajes/create', [PesajeController::class, 'create']);
    Route::post('/pesajes', [PesajeController::class, 'store']);

    // 🔥 PREDICCIÓN (NUEVO)
    Route::get('/prediccion', [PrediccionController::class, 'index'])->name('prediccion');

});