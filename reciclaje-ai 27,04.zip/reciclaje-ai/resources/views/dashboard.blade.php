<x-app-layout>

<div class="p-6 bg-gray-100 min-h-screen">

    <!-- 🔹 GRID PRINCIPAL -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">

        <!-- IZQUIERDA -->
        <div class="lg:col-span-2 space-y-6">

            <!-- TARJETAS -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">

                <div class="bg-white p-4 rounded-xl shadow">
                    <p class="text-gray-500 text-sm">Total hoy</p>
                    <h2 class="text-2xl font-bold text-green-600">{{ $totalHoy }} kg</h2>
                </div>

                <div class="bg-white p-4 rounded-xl shadow">
                    <p class="text-gray-500 text-sm">Total general</p>
                    <h2 class="text-2xl font-bold text-blue-600">{{ $totalGeneral }} kg</h2>
                </div>

                <div class="bg-white p-4 rounded-xl shadow">
                    <p class="text-gray-500 text-sm">Predicción IA</p>
                    <h2 class="text-2xl font-bold text-purple-600">
                        {{ number_format($prediccion,2) }} kg
                    </h2>
                </div>

            </div>

            <!-- GRÁFICA -->
            <div class="bg-white p-5 rounded-xl shadow">
                <h2 class="text-lg font-semibold text-gray-700 mb-3">Tendencia de reciclaje</h2>
                <canvas id="grafica"></canvas>
            </div>

        </div>

        <!-- DERECHA -->
        <div class="space-y-6">

            <!-- ANÁLISIS -->
            <div class="bg-white p-5 rounded-xl shadow">
                <h2 class="text-md font-semibold text-gray-700 mb-2">Análisis</h2>

                @if($prediccion > 60)
                    <p class="text-green-600 font-medium">Alto nivel de reciclaje esperado</p>
                @else
                    <p class="text-red-500 font-medium">Nivel bajo, mejorar recolección</p>
                @endif

                <p class="text-sm text-gray-500 mt-2">
                    Datos atípicos: {{ $outliers ?? 0 }}
                </p>
            </div>

            <!-- ÚLTIMOS -->
            <div class="bg-white p-5 rounded-xl shadow">
                <h2 class="text-md font-semibold text-gray-700 mb-2">Últimos registros</h2>

                <div class="space-y-2 text-sm">
                    @foreach($ultimos as $p)
                        <div class="flex justify-between border-b pb-1">
                            <span class="text-gray-600">{{ ucfirst($p->material) }}</span>
                            <span class="font-semibold">{{ $p->peso }} kg</span>
                        </div>
                    @endforeach
                </div>
            </div>

            <!-- BOTÓN -->
            <a href="/pesajes/create"
               class="block text-center bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 rounded-xl shadow transition">
                Registrar nuevo pesaje
            </a>

        </div>

    </div>

</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
    new Chart(document.getElementById('grafica'), {
        type: 'line',
        data: {
            labels: @json($fechas),
            datasets: [{
                label: 'Kg por día',
                data: @json($totales),
                borderWidth: 2,
                tension: 0.3
            }]
        }
    });
</script>

</x-app-layout>