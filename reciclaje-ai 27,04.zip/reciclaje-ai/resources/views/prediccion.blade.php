<x-app-layout>

<div class="max-w-7xl mx-auto px-6 py-8">

    <!-- TÍTULO -->
    <h2 class="text-2xl font-semibold text-gray-800 mb-6">
        Predicción de Reciclaje
    </h2>

    <!-- TARJETAS -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">

        <!-- Predicción -->
        <div class="bg-white p-6 rounded-xl shadow">
            <p class="text-gray-500 text-sm">Predicción para mañana</p>
            <h3 class="text-3xl font-bold text-blue-600">
                {{ number_format($prediccion, 2) }} kg
            </h3>
        </div>

        <!-- Nivel -->
        <div class="bg-white p-6 rounded-xl shadow">
            <p class="text-gray-500 text-sm">Nivel esperado</p>

            @if($prediccion > 60)
                <h3 class="text-xl font-semibold text-green-600">Alto</h3>
            @elseif($prediccion > 30)
                <h3 class="text-xl font-semibold text-yellow-500">Medio</h3>
            @else
                <h3 class="text-xl font-semibold text-red-500">Bajo</h3>
            @endif
        </div>

        <!-- Outliers -->
        <div class="bg-white p-6 rounded-xl shadow">
            <p class="text-gray-500 text-sm">Datos atípicos detectados</p>
            <h3 class="text-3xl font-bold text-gray-800">
                {{ $outliers }}
            </h3>
        </div>

    </div>

    <!-- ANÁLISIS -->
    <div class="bg-white p-6 rounded-xl shadow mb-8">

        <h3 class="text-lg font-semibold text-gray-700 mb-3">
            Análisis del sistema
        </h3>

        <p class="text-gray-600 mb-2">
            La predicción se basa en los datos históricos registrados en el sistema.
        </p>

        @if($prediccion > 60)
            <p class="text-green-600 font-medium">
                Se espera un comportamiento positivo en la recolección de residuos.
            </p>
        @else
            <p class="text-red-500 font-medium">
                Se recomienda mejorar la recolección y clasificación de residuos.
            </p>
        @endif

    </div>

    <!-- GRÁFICA -->
    <div class="bg-white p-6 rounded-xl shadow">

        <h3 class="text-lg font-semibold text-gray-700 mb-4">
            Tendencia histórica
        </h3>

        <canvas id="graficaPrediccion"></canvas>

    </div>

</div>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
    new Chart(document.getElementById('graficaPrediccion'), {
        type: 'line',
        data: {
            labels: @json($fechas),
            datasets: [{
                label: 'Kg por día',
                data: @json($totales),
                borderWidth: 2,
                tension: 0.3
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: true
                }
            }
        }
    });
</script>

</x-app-layout>